﻿using System;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Products;
using SlothEnterprise.ProductApplication.Submitters;

namespace SlothEnterprise.ProductApplication
{
    public class ApplicationSubmitterFactory : IApplicationSubmitterFactory
    {
        private readonly ISelectInvoiceService _selectInvoiceService;
        private readonly IConfidentialInvoiceService _confidentialInvoiceWebService;
        private readonly IBusinessLoansService _businessLoansService;

        public ApplicationSubmitterFactory(ISelectInvoiceService selectInvoiceService, IConfidentialInvoiceService confidentialInvoiceWebService, IBusinessLoansService businessLoansService)
        {
            _selectInvoiceService = selectInvoiceService;
            _confidentialInvoiceWebService = confidentialInvoiceWebService;
            _businessLoansService = businessLoansService;
        }

        public IApplicationSubmitter CreateApplicationSubmitter(ISellerApplication application)
        {
            switch (application.Product)
            {
                case SelectiveInvoiceDiscount sid:
                    return new SelectiveInvoiceDiscountSubmitter(_selectInvoiceService, application, sid);
                case ConfidentialInvoiceDiscount cid:
                    return new ConfidentialInvoiceDiscountSubmitter(_confidentialInvoiceWebService, application, cid);
                case BusinessLoans loans:
                    return new BusinessLoansSubmitter(_businessLoansService, application, loans);
                default:
                    throw new InvalidOperationException();
            }
        }
    }
}
