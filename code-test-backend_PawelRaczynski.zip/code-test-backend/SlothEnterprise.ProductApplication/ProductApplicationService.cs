﻿using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;

namespace SlothEnterprise.ProductApplication
{
    public class ProductApplicationService
    {
        private readonly IApplicationSubmitterFactory _applicationSubmitterFactory;

        public ProductApplicationService(ISelectInvoiceService selectInvoiceService,
            IConfidentialInvoiceService confidentialInvoiceWebService, IBusinessLoansService businessLoansService)
        {
            _applicationSubmitterFactory = new ApplicationSubmitterFactory(selectInvoiceService, confidentialInvoiceWebService,
                businessLoansService);
        }

        public ProductApplicationService(IApplicationSubmitterFactory applicationSubmitterFactory)
        {
            _applicationSubmitterFactory = applicationSubmitterFactory;
        }

        public int SubmitApplicationFor(ISellerApplication application)
        {
            var applicationSubmitter = _applicationSubmitterFactory.CreateApplicationSubmitter(application);
            return applicationSubmitter.SubmitApplication();
        }
    }
}
