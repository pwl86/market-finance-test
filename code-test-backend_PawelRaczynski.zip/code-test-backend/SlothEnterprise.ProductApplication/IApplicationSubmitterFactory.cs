﻿namespace SlothEnterprise.ProductApplication
{
    using Applications;
    using Submitters;

    /// <summary>
    /// Factory for ApplicationSubmitters
    /// </summary>
    public interface IApplicationSubmitterFactory
    {
        /// <summary>
        /// Creates instance of application submitter.
        /// </summary>
        /// <param name="application"></param>
        /// <returns></returns>
        IApplicationSubmitter CreateApplicationSubmitter(ISellerApplication application);
    }
}
