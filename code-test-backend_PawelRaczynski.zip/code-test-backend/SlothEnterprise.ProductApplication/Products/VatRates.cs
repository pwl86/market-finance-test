﻿namespace SlothEnterprise.ProductApplication.Products
{
    public class VatRates
    {
        public static decimal UkVatRate => 0.20M;
    }
}