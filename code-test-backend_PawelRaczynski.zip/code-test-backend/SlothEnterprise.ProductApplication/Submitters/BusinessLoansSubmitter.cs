﻿using System;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication.Submitters
{
    public class BusinessLoansSubmitter : IApplicationSubmitter
    {
        private readonly IBusinessLoansService _businessLoansService;
        private readonly ISellerApplication _application;
        private readonly BusinessLoans _loans;

        public BusinessLoansSubmitter(IBusinessLoansService businessLoansService, ISellerApplication application, BusinessLoans loans)
        {
            _businessLoansService = businessLoansService;
            _application = application;
            _loans = loans;
        }

        public int SubmitApplication()
        {
            if (_application.CompanyData == null)
                throw new ArgumentNullException($"CompanyData of an application cannot be null");

            var result = _businessLoansService.SubmitApplicationFor(new CompanyDataRequest
            {
                CompanyFounded = _application.CompanyData.Founded,
                CompanyNumber = _application.CompanyData.Number,
                CompanyName = _application.CompanyData.Name,
                DirectorName = _application.CompanyData.DirectorName
            }, new LoansRequest
            {
                InterestRatePerAnnum = _loans.InterestRatePerAnnum,
                LoanAmount = _loans.LoanAmount
            });
            return (result.Success) ? result.ApplicationId ?? -1 : -1;
        }
    }
}
