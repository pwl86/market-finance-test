﻿namespace SlothEnterprise.ProductApplication.Submitters
{
    /// <summary>
    /// Application submitter.
    /// </summary>
    public interface IApplicationSubmitter
    {
        /// <summary>
        /// Executes submission of an application.
        /// </summary>
        /// <returns></returns>
        int SubmitApplication();
    }
}
