﻿using System;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;


namespace SlothEnterprise.ProductApplication.Submitters
{
    public class ConfidentialInvoiceDiscountSubmitter : IApplicationSubmitter
    {
        private readonly IConfidentialInvoiceService _confidentialInvoiceWebService;
        private readonly ISellerApplication _application;
        private readonly ConfidentialInvoiceDiscount _cid;

        public ConfidentialInvoiceDiscountSubmitter(IConfidentialInvoiceService confidentialInvoiceWebService, ISellerApplication application, ConfidentialInvoiceDiscount cid)
        {
            _confidentialInvoiceWebService = confidentialInvoiceWebService;
            _application = application;
            _cid = cid;
        }

        public int SubmitApplication()
        {
            if (_application.CompanyData == null)
                throw new ArgumentNullException($"CompanyData of an application cannot be null");

            var result = _confidentialInvoiceWebService.SubmitApplicationFor(
                new CompanyDataRequest
                {
                    CompanyFounded = _application.CompanyData.Founded,
                    CompanyNumber = _application.CompanyData.Number,
                    CompanyName = _application.CompanyData.Name,
                    DirectorName = _application.CompanyData.DirectorName
                }, _cid.TotalLedgerNetworth, _cid.AdvancePercentage, _cid.VatRate);

            return (result.Success) ? result.ApplicationId ?? -1 : -1;
        }
    }
}
