﻿using System;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication.Submitters
{
    public class SelectiveInvoiceDiscountSubmitter : IApplicationSubmitter
    {
        private readonly ISelectInvoiceService _selectInvoiceService;
        private readonly ISellerApplication _application;
        private readonly SelectiveInvoiceDiscount _sid;

        public SelectiveInvoiceDiscountSubmitter(ISelectInvoiceService selectInvoiceService, ISellerApplication application, SelectiveInvoiceDiscount sid)
        {
            _selectInvoiceService = selectInvoiceService;
            _application = application;
            _sid = sid;
        }

        public int SubmitApplication()
        {
            if (_application.CompanyData == null)
                throw new ArgumentNullException($"CompanyData of an application cannot be null");

            return _selectInvoiceService.SubmitApplicationFor(_application.CompanyData.Number.ToString(),
                _sid.InvoiceAmount, _sid.AdvancePercentage);
        }
    }
}
