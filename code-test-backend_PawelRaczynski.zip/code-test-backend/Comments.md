Issues:
- Dependency injection is missing. I highly recommend using it.
- Service methods are synchronous. I would recommend asynchronous code, since they are calling external services (`SubmitApplication` method)
- Code is not commented properly. Some classes for example: `SelectiveInvoiceDiscount` have comments but others not (for example `ConfidentialInvoiceDiscount`)
- Errors are not being logged anywhere (`result.Errors`) - at least logging to a file (or event to *ApplicationInsights*)
- Code of submitters is not unit tested (need to mock web service and write tests)
