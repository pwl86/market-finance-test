﻿using Xunit;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ProductApplicationTests
    {

        [Fact]
        public void ThisIsTrue()
        {
            Assert.Equal(1, 1);
        }
    }
}
