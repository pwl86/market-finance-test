﻿using System;

namespace SlothEnterprise.ProductApplication.Tests
{
    using Applications;
    using Products;
    using Submitters;
    using Xunit;

    public class ApplicationSubmitterFactoryTests
    {
        public ApplicationSubmitterFactory _testObject;

        public ApplicationSubmitterFactoryTests()
        {
            _testObject = new ApplicationSubmitterFactory(null, null, null);
        }

        [Fact]
        public void ShouldCreateSelectiveInvoiceDiscountSubmitter()
        {
            var result = _testObject.CreateApplicationSubmitter(new SellerApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new SelectiveInvoiceDiscount()
            });
            Assert.NotNull(result);
            Assert.IsType<SelectiveInvoiceDiscountSubmitter>(result);
        }

        [Fact]
        public void ShouldCreateConfidentialInvoiceDiscountSubmitter()
        {
            var result = _testObject.CreateApplicationSubmitter(new SellerApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new ConfidentialInvoiceDiscount()
            });
            Assert.NotNull(result);
            Assert.IsType<ConfidentialInvoiceDiscountSubmitter>(result);
        }

        [Fact]
        public void ShouldCreateBusinessLoansSubmitter()
        {
            var result = _testObject.CreateApplicationSubmitter(new SellerApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new BusinessLoans()
            });
            Assert.NotNull(result);
            Assert.IsType<BusinessLoansSubmitter>(result);
        }

        [Fact]
        public void ShouldThrowInvalidOperationException()
        {
            Assert.Throws<InvalidOperationException>(() => 
                _testObject.CreateApplicationSubmitter(new SellerApplication()
                {
                    CompanyData = new SellerCompanyData(),
                    Product = new NotSupportedProduct()
                }));
        }
    }

    class NotSupportedProduct : IProduct
    {
        public int Id { get; }
    }
}
